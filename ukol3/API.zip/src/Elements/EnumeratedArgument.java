package Elements;


public class EnumeratedArgument extends Argument {

	public EnumeratedArgument(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * Nastavi mozne vymenovane(enum) hodnoty. 
	 *
	 * @param  value	hodnota
	 * @return vrati sam seba (kvoli chain of responsibility)
	 */
	public Argument setPossibleValue(String value) {
		return null;
	}

}
