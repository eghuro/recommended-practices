package Elements;


public class BooleanArgument extends Argument {

	public BooleanArgument(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

}
